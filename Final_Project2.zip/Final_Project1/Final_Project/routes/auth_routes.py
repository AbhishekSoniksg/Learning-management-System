from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from extensions import db, bcrypt
from models import User, CourseRequest, InstructorInterest

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect_role(current_user)

    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()

        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            flash('Login Successful!', 'success')
            return redirect_role(user)
        else:
            flash('Login unsuccessful. Please check email and password.', 'danger')

    return render_template('auth/login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect_role(current_user)

    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')

        if role == 'admin':
            flash('Admin registration is disabled. Please contact the system administrator.', 'warning')
            return redirect(url_for('auth.register'))

        # Check existing
        if User.query.filter_by(email=email).first():
            flash('Email already exists.', 'warning')
            return redirect(url_for('auth.register'))

        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(name=name, full_name=name, email=email, password=hashed_password, role=role)
        db.session.add(user)
        db.session.commit()
        if role == 'instructor':
            selected_requests = request.form.getlist('course_interest_ids')
            for request_id in selected_requests:
                if CourseRequest.query.get(request_id):
                    db.session.add(InstructorInterest(instructor_id=user.id, request_id=request_id))
            db.session.commit()
        flash(f'Account created for {name}! You can now login.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('auth/register.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))

def redirect_role(user):
    if user.role == 'admin':
        return redirect(url_for('admin.dashboard'))
    elif user.role == 'instructor':
        return redirect(url_for('instructor.dashboard'))
    elif user.role == 'student':
        return redirect(url_for('student.dashboard'))
    else:
        return redirect(url_for('main.home'))
