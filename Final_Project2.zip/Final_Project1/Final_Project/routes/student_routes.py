from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from extensions import db
from models import Course, Enrollment, Quiz, Result, Question, CourseCategory, CourseCategoryMapping, CourseRequest, CourseRequestVote, Badge, UserBadge, Notification, AttendanceSession, AttendanceRecord, Content, CourseReview, StudentProgress, Certificate, User
from datetime import datetime
from sqlalchemy import func
from utils import create_notification, check_and_award_badges

student_bp = Blueprint('student', __name__)

@student_bp.route('/dashboard')
@login_required
def dashboard():
    student_id = current_user.id
    search = request.args.get('search', '')
    category_filter = request.args.get('category', '')

    enrolled_courses_rows = db.session.query(Course, Enrollment.enrolled_date.label('enrolled_at')) \
        .join(Enrollment, Enrollment.course_id == Course.id) \
        .filter(Enrollment.user_id == student_id, Course.status == 'Approved') \
        .order_by(Enrollment.enrolled_date.desc()).all()

    enrolled_courses = [
        {
            'id': course.id,
            'title': course.title,
            'description': course.description,
            'enrolled_at': enrolled_at
        }
        for course, enrolled_at in enrolled_courses_rows
    ]

    available_query = db.session.query(
        Course,
        User.full_name.label('instructor_name'),
        func.coalesce(func.avg(CourseReview.rating), 0).label('avg_rating'),
        func.count(func.distinct(Enrollment.id)).label('enrollment_count')
    ).join(User, Course.instructor_id == User.id) \
     .outerjoin(CourseReview, CourseReview.course_id == Course.id) \
     .outerjoin(Enrollment, Enrollment.course_id == Course.id) \
     .filter(Course.status == 'Approved') \
     .filter(~Course.id.in_(db.session.query(Enrollment.course_id).filter(Enrollment.user_id == student_id)))

    if search:
        available_query = available_query.filter(
            (Course.title.ilike(f'%{search}%')) | (Course.description.ilike(f'%{search}%'))
        )

    if category_filter:
        try:
            category_id = int(category_filter)
        except ValueError:
            category_id = None

        if category_id:
            available_query = available_query.join(CourseCategoryMapping, CourseCategoryMapping.course_id == Course.id) \
                .filter(CourseCategoryMapping.category_id == category_id)

    available_courses_rows = available_query.group_by(Course.id, User.full_name).order_by(Course.created_at.desc()).all()

    available_courses = [
        {
            'id': course.id,
            'title': course.title,
            'description': course.description,
            'avg_rating': avg_rating,
            'enrollment_count': enrollment_count,
            'instructor_name': instructor_name
        }
        for course, instructor_name, avg_rating, enrollment_count in available_courses_rows
    ]

    recent_results_rows = db.session.query(Result, Quiz.title.label('assessment_title'), Course.title.label('course_title')) \
        .join(Quiz, Result.quiz_id == Quiz.id) \
        .join(Course, Quiz.course_id == Course.id) \
        .filter(Result.user_id == student_id) \
        .order_by(Result.submitted_at.desc()).limit(5).all()

    recent_results = [
        {
            'assessment_title': assessment_title,
            'course_title': course_title,
            'score': result.score,
            'total_marks': result.total_marks,
            'percentage': result.percentage or 0,
            'submitted_at': result.submitted_at
        }
        for result, assessment_title, course_title in recent_results_rows
    ]

    course_requests_rows = db.session.query(
        CourseRequest,
        func.count(CourseRequestVote.id).label('votes')
    ).outerjoin(CourseRequestVote, CourseRequestVote.request_id == CourseRequest.id) \
     .filter(CourseRequest.status == 'pending') \
     .group_by(CourseRequest.id) \
     .order_by(func.count(CourseRequestVote.id).desc(), CourseRequest.created_at.desc()).all()

    course_requests = [
        {
            'id': req.id,
            'title': req.title,
            'description': req.description,
            'votes': votes
        }
        for req, votes in course_requests_rows
    ]

    voted_request_ids = {
        vote.request_id for vote in CourseRequestVote.query.filter_by(student_id=student_id).all()
    }

    categories = CourseCategory.query.order_by(CourseCategory.name.asc()).all()

    badges = db.session.query(Badge).join(UserBadge, UserBadge.badge_id == Badge.id) \
        .filter(UserBadge.user_id == student_id).order_by(UserBadge.earned_at.desc()).all()

    recent_attendance_rows = db.session.query(
        AttendanceSession.session_date,
        AttendanceSession.topic,
        AttendanceRecord.status,
        Course.title.label('course_title')
    ).join(Course, AttendanceSession.course_id == Course.id) \
     .outerjoin(AttendanceRecord, (AttendanceRecord.session_id == AttendanceSession.id) & (AttendanceRecord.student_id == student_id)) \
     .filter(AttendanceSession.course_id.in_(db.session.query(Enrollment.course_id).filter(Enrollment.user_id == student_id))) \
     .order_by(AttendanceSession.session_date.desc()).limit(15).all()

    recent_attendance = [
        {
            'session_date': row.session_date,
            'topic': row.topic,
            'status': row.status,
            'course_title': row.course_title
        }
        for row in recent_attendance_rows
    ]

    return render_template('student_dashboard.html',
                           enrolled_courses=enrolled_courses,
                           available_courses=available_courses,
                           recent_results=recent_results,
                           course_requests=course_requests,
                           voted_request_ids=voted_request_ids,
                           categories=categories,
                           search=search,
                           category_filter=category_filter,
                           badges=badges,
                           recent_attendance=recent_attendance)

@student_bp.route('/courses')
@login_required
def browse_courses():
    courses = Course.query.filter_by(status='Approved').all() # STRICT MODE: Only approved
    user_enrollments = Enrollment.query.filter_by(user_id=current_user.id).all()
    enrolled_course_ids = [e.course_id for e in user_enrollments]
    return render_template('courses/course_list.html', courses=courses, enrolled_course_ids=enrolled_course_ids)

# ... (enroll route remains same, skipped for brevity in replacement if not modifying) ...
@student_bp.route('/enroll/<int:course_id>', methods=['POST'])
@login_required
def enroll(course_id):
    existing = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    if existing:
        flash('Already enrolled.', 'info')
        return redirect(url_for('student.dashboard'))

    enrollment = Enrollment(user_id=current_user.id, course_id=course_id)
    db.session.add(enrollment)

    course = Course.query.get(course_id)
    if course:
        create_notification(course.instructor_id, 'New Student Enrollment',
                            f"{current_user.full_name or current_user.name} enrolled in your course: {course.title}",
                            url_for('instructor.instructor_course_details', course_id=course.id))

    db.session.commit()
    check_and_award_badges(current_user.id)
    flash('Successfully enrolled in the course!', 'success')
    return redirect(url_for('student.dashboard'))

@student_bp.route('/learn/<int:course_id>')
@login_required
def learning_page(course_id):
    course = Course.query.get_or_404(course_id)
    enrollment = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    if not enrollment:
         flash('Please enroll first.', 'danger')
         return redirect(url_for('student.browse_courses'))
    
    quizzes = Quiz.query.filter_by(course_id=course.id).all()
    # Check if quiz taken
    taken_quizzes = [r.quiz_id for r in current_user.results]
    
    return render_template('courses/learn.html', course=course, enrollment=enrollment, quizzes=quizzes, taken_quizzes=taken_quizzes)

@student_bp.route('/quiz/<int:quiz_id>', methods=['GET', 'POST'])
@login_required
def take_quiz(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    if request.method == 'POST':
        score = 0
        total_marks = 0
        for q in quiz.questions:
            total_marks += q.marks or 1
            selected_option = request.form.get(f'q_{q.id}')
            if selected_option == q.correct_option:
                score += q.marks or 1
        percentage = (score / total_marks * 100) if total_marks > 0 else 0

        result = Result(user_id=current_user.id, quiz_id=quiz.id, score=score, total_marks=total_marks, percentage=percentage)
        db.session.add(result)
        db.session.commit()
        
        # Auto-complete course if key quiz passed? (Optional gamification)
        
        flash(f'Assessment submitted! You scored {score}/{total_marks} ({percentage:.2f}%)', 'info')
        return redirect(url_for('student.learning_page', course_id=quiz.course_id))

    return render_template('courses/take_quiz.html', quiz=quiz)

@student_bp.route('/complete/<int:course_id>', methods=['POST'])
@login_required
def mark_complete(course_id):
    enrollment = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    if enrollment:
        if enrollment.progress < 100:
            enrollment.progress = min(100, enrollment.progress + 25)
        
        if enrollment.progress == 100:
            enrollment.completed = True
            
        db.session.commit()
    return redirect(url_for('student.dashboard'))

@student_bp.route('/certificate/<int:course_id>')
@login_required
def certificate(course_id):
    enrollment = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    if not enrollment or not enrollment.completed:
        flash('Complete the course to get the certificate!', 'warning')
        return redirect(url_for('student.dashboard'))
        
    return render_template('certificates/certificate.html', user=current_user, course=enrollment.course, date=datetime.now().strftime('%Y-%m-%d'))

@student_bp.route('/request_course', methods=['POST'])
@login_required
def request_course():
    title = request.form.get('title', '').strip()
    description = request.form.get('description', '').strip()

    if not title:
        flash('Course title is required.', 'warning')
        return redirect(url_for('student.dashboard'))

    existing = CourseRequest.query.filter(func.lower(CourseRequest.title) == title.lower(), CourseRequest.status == 'pending').first()
    if existing:
        request_id = existing.id
    else:
        new_req = CourseRequest(title=title, description=description, requested_by=current_user.id)
        db.session.add(new_req)
        db.session.commit()
        request_id = new_req.id

    if not CourseRequestVote.query.filter_by(request_id=request_id, student_id=current_user.id).first():
        db.session.add(CourseRequestVote(request_id=request_id, student_id=current_user.id))
        db.session.commit()
        flash('Course request submitted and supported!', 'success')
    else:
        flash('You have already supported this course request.', 'info')

    return redirect(url_for('student.dashboard'))

@student_bp.route('/support_course/<int:request_id>', methods=['POST'])
@login_required
def support_course(request_id):
    if not CourseRequestVote.query.filter_by(request_id=request_id, student_id=current_user.id).first():
        db.session.add(CourseRequestVote(request_id=request_id, student_id=current_user.id))
        db.session.commit()
        flash('Thanks! You supported this course request.', 'success')
    else:
        flash('You have already supported this course request.', 'info')
    return redirect(url_for('student.dashboard'))

@student_bp.route('/course/<int:course_id>')
@login_required
def student_course_view(course_id):
    enrollment = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    if not enrollment:
        flash('You are not enrolled in this course.', 'danger')
        return redirect(url_for('student.dashboard'))

    course = Course.query.get_or_404(course_id)
    materials = Content.query.filter_by(course_id=course_id).order_by(Content.created_at.desc()).all()
    assessments = Quiz.query.filter_by(course_id=course_id).order_by(Quiz.created_at.desc()).all()

    attendance_summary = db.session.query(
        AttendanceSession.id.label('session_id'),
        AttendanceSession.session_date,
        AttendanceSession.topic,
        AttendanceRecord.status
    ).outerjoin(AttendanceRecord, (AttendanceRecord.session_id == AttendanceSession.id) & (AttendanceRecord.student_id == current_user.id)) \
     .filter(AttendanceSession.course_id == course_id).order_by(AttendanceSession.session_date.desc()).all()

    results = db.session.query(Result, Quiz.title.label('assessment_title')) \
        .join(Quiz, Result.quiz_id == Quiz.id) \
        .filter(Result.user_id == current_user.id, Quiz.course_id == course_id).all()

    # Get completed materials
    completed_progress = StudentProgress.query.filter_by(
        student_id=current_user.id,
        course_id=course_id,
        completed=True
    ).all()
    completed_materials = [p.material_id for p in completed_progress]

    # Check course completion
    total_materials = len(materials)
    completed_materials_count = len(completed_materials)
    total_assessments = len(assessments)
    completed_assessments = len(results)
    
    course_completed = False
    if total_materials > 0 and total_assessments > 0:
        course_completed = (completed_materials_count == total_materials and 
                          completed_assessments == total_assessments)
    elif total_materials > 0:
        course_completed = (completed_materials_count == total_materials)
    elif total_assessments > 0:
        course_completed = (completed_assessments == total_assessments)

    return render_template('student_course_view.html',
                           course=course,
                           materials=materials,
                           assessments=assessments,
                           results=results,
                           attendance_summary=attendance_summary,
                           completed_materials=completed_materials,
                           course_completed=course_completed)

@student_bp.route('/take_assessment/<int:assessment_id>', methods=['GET', 'POST'])
@login_required
def take_assessment(assessment_id):
    assessment = Quiz.query.get_or_404(assessment_id)

    existing_result = Result.query.filter_by(user_id=current_user.id, quiz_id=assessment_id).first()
    if existing_result:
        flash('You have already taken this assessment.', 'info')
        return redirect(url_for('student.dashboard'))

    if request.method == 'POST':
        score = 0
        total_marks = 0
        for question in assessment.questions:
            total_marks += question.marks or 1
            user_answer = request.form.get(f'question_{question.id}')
            if user_answer == question.correct_option:
                score += question.marks or 1

        percentage = (score / total_marks * 100) if total_marks > 0 else 0
        result = Result(user_id=current_user.id, quiz_id=assessment.id, score=score, total_marks=total_marks, percentage=percentage)
        db.session.add(result)
        
        # Update enrollment progress
        course_id = assessment.course_id
        enrollment = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
        if enrollment:
            total_materials = Content.query.filter_by(course_id=course_id).count()
            completed_materials = StudentProgress.query.filter_by(
                student_id=current_user.id,
                course_id=course_id,
                completed=True
            ).count()
            
            total_assessments = Quiz.query.filter_by(course_id=course_id).count()
            completed_assessments = Result.query.join(Quiz).filter(
                Result.user_id == current_user.id,
                Quiz.course_id == course_id
            ).count()
            
            total_items = total_materials + total_assessments
            completed_items = completed_materials + completed_assessments
            
            if total_items > 0:
                enrollment.progress = int((completed_items / total_items) * 100)
                if enrollment.progress >= 100:
                    enrollment.completed = True
        
        db.session.commit()

        flash(f'Assessment submitted! You scored {score}/{total_marks} ({percentage:.2f}%)', 'success')
        return redirect(url_for('student.student_course_view', course_id=course_id))

    questions = Question.query.filter_by(quiz_id=assessment.id).all()
    return render_template('take_assessment.html', assessment=assessment, questions=questions)

@student_bp.route('/my_performance')
@login_required
def my_performance():
    results_rows = db.session.query(Result, Quiz.title.label('assessment_title'), Course.title.label('course_title')) \
        .join(Quiz, Result.quiz_id == Quiz.id) \
        .join(Course, Quiz.course_id == Course.id) \
        .filter(Result.user_id == current_user.id).order_by(Result.submitted_at.desc()).all()

    results = [
        {
            'assessment_title': assessment_title,
            'course_title': course_title,
            'score': result.score,
            'total_marks': result.total_marks,
            'percentage': result.percentage,
            'submitted_at': result.submitted_at
        }
        for result, assessment_title, course_title in results_rows
    ]

    avg_percentage = sum(r['percentage'] or 0 for r in results) / len(results) if results else 0
    total_assessments = len(results)

    return render_template('my_performance.html',
                           results=results,
                           avg_percentage=avg_percentage,
                           total_assessments=total_assessments)

@student_bp.route('/course/<int:course_id>/rate', methods=['POST'])
@login_required
def rate_course(course_id):
    rating = int(request.form.get('rating', 0))
    review = request.form.get('review', '')
    existing = CourseReview.query.filter_by(course_id=course_id, student_id=current_user.id).first()
    if existing:
        existing.rating = rating
        existing.review = review
        flash('Your review has been updated!', 'success')
    else:
        db.session.add(CourseReview(course_id=course_id, student_id=current_user.id, rating=rating, review=review))
        flash('Thank you for your review!', 'success')
    db.session.commit()
    return redirect(url_for('student.student_course_view', course_id=course_id))

@student_bp.route('/course/<int:course_id>/progress')
@login_required
def course_progress(course_id):
    materials = db.session.query(Content, StudentProgress.completed.label('is_completed')) \
        .outerjoin(StudentProgress, (StudentProgress.material_id == Content.id) & (StudentProgress.student_id == current_user.id) & (StudentProgress.course_id == course_id)) \
        .filter(Content.course_id == course_id).order_by(Content.created_at.asc()).all()

    total_materials = len(materials)
    completed_materials = sum(1 for _m, completed in materials if completed)
    progress_percentage = (completed_materials / total_materials * 100) if total_materials > 0 else 0

    return render_template('course_progress.html',
                           materials=materials,
                           progress_percentage=progress_percentage,
                           course_id=course_id)

@student_bp.route('/material/<int:material_id>/complete', methods=['POST'])
@login_required
def complete_material(material_id):
    course_id = request.form.get('course_id')
    progress = StudentProgress.query.filter_by(student_id=current_user.id, course_id=course_id, material_id=material_id).first()
    if progress:
        progress.completed = True
        progress.completed_at = datetime.utcnow()
    else:
        db.session.add(StudentProgress(student_id=current_user.id, course_id=course_id, material_id=material_id, completed=True, completed_at=datetime.utcnow()))
    
    # Update enrollment progress
    enrollment = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    if enrollment:
        total_materials = Content.query.filter_by(course_id=course_id).count()
        completed_materials = StudentProgress.query.filter_by(
            student_id=current_user.id,
            course_id=course_id,
            completed=True
        ).count()
        
        total_assessments = Quiz.query.filter_by(course_id=course_id).count()
        completed_assessments = Result.query.join(Quiz).filter(
            Result.user_id == current_user.id,
            Quiz.course_id == course_id
        ).count()
        
        total_items = total_materials + total_assessments
        completed_items = completed_materials + completed_assessments
        
        if total_items > 0:
            enrollment.progress = int((completed_items / total_items) * 100)
            if enrollment.progress >= 100:
                enrollment.completed = True
                flash('Congratulations! You have completed this course!', 'success')
    
    db.session.commit()
    flash('Material marked as completed!', 'success')
    return redirect(url_for('student.student_course_view', course_id=course_id))

@student_bp.route('/certificate/<int:course_id>/view')
@login_required
def view_certificate(course_id):
    # Check enrollment and completion status
    enrollment = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    if not enrollment:
        flash('You are not enrolled in this course.', 'danger')
        return redirect(url_for('student.dashboard'))
    
    # Check if all materials and assessments are completed
    total_materials = Content.query.filter_by(course_id=course_id).count()
    completed_materials = StudentProgress.query.filter_by(
        student_id=current_user.id,
        course_id=course_id,
        completed=True
    ).count()
    
    total_assessments = Quiz.query.filter_by(course_id=course_id).count()
    completed_assessments = db.session.query(Result).join(Quiz, Result.quiz_id == Quiz.id) \
        .filter(Result.user_id == current_user.id, Quiz.course_id == course_id).count()
    
    # Verify complete course completion
    is_completed = False
    if total_materials > 0 and total_assessments > 0:
        is_completed = (completed_materials == total_materials and 
                       completed_assessments == total_assessments)
    elif total_materials > 0:
        is_completed = (completed_materials == total_materials)
    elif total_assessments > 0:
        is_completed = (completed_assessments == total_assessments)
    
    if not is_completed:
        flash('Please complete all materials and assessments to earn your certificate.', 'warning')
        return redirect(url_for('student.student_course_view', course_id=course_id))
    
    # Update enrollment to mark as completed
    if not enrollment.completed:
        enrollment.completed = True
        enrollment.progress = 100
        db.session.commit()

    # Generate or retrieve certificate
    certificate = Certificate.query.filter_by(student_id=current_user.id, course_id=course_id).first()
    if not certificate:
        import random, string
        cert_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=12))
        certificate = Certificate(student_id=current_user.id, course_id=course_id, certificate_code=cert_code)
        db.session.add(certificate)
        db.session.commit()

    course = Course.query.get_or_404(course_id)
    return render_template('certificate.html', certificate=certificate, course=course)
