from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from extensions import db
from models import User, Course, CourseRequest, CourseRequestVote, InstructorInterest, Result
from sqlalchemy import func

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    users = User.query.order_by(User.created_at.desc()).all()
    courses = Course.query.order_by(Course.created_at.desc()).all()
    pending_courses = [c for c in courses if c.status == 'Pending']

    eligible_requests = db.session.query(
        CourseRequest,
        func.count(CourseRequestVote.id).label('votes')
    ).outerjoin(CourseRequestVote, CourseRequest.id == CourseRequestVote.request_id) \
     .filter(CourseRequest.status == 'pending') \
     .group_by(CourseRequest.id) \
     .having(func.count(CourseRequestVote.id) >= 4) \
     .order_by(func.count(CourseRequestVote.id).desc(), CourseRequest.created_at.desc()) \
     .all()

    instructors = User.query.filter_by(role='instructor', status='active').order_by(User.full_name.asc()).all()

    eligible_request_interests = {}
    for req, _votes in eligible_requests:
        interests = db.session.query(User).join(InstructorInterest, InstructorInterest.instructor_id == User.id) \
            .filter(InstructorInterest.request_id == req.id).order_by(User.full_name.asc()).all()
        eligible_request_interests[req.id] = interests

    return render_template('admin_dashboard.html',
                           user=current_user,
                           users=users,
                           courses=courses,
                           pending_courses=pending_courses,
                           eligible_requests=eligible_requests,
                           instructors=instructors,
                           eligible_request_interests=eligible_request_interests)

@admin_bp.route('/approve-course/<int:course_id>')
@login_required
def approve_course(course_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    course = Course.query.get_or_404(course_id)
    course.status = 'Approved'
    db.session.commit()
    flash(f'Course "{course.title}" approved!', 'success')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/reject-course/<int:course_id>')
@login_required
def reject_course(course_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    course = Course.query.get_or_404(course_id)
    course.status = 'Rejected'
    db.session.commit()
    flash('Course rejected.', 'info')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/delete-user/<int:user_id>')
@login_required
def delete_user(user_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    user = User.query.get_or_404(user_id)
    if user.role == 'admin':
         flash('Cannot delete an admin.', 'danger')
    else:
        db.session.delete(user)
        db.session.commit()
        flash('User deleted.', 'info')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/users')
@login_required
def admin_users():
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin_users.html', users=users)

@admin_bp.route('/analytics')
@login_required
def admin_analytics():
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))

    enrollment_data = db.session.query(
        Course.title,
        func.count().label('count')
    ).outerjoin(Course.enrollments).filter(Course.status == 'Approved') \
     .group_by(Course.id).order_by(func.count().desc()).limit(10).all()

    performance_data = db.session.query(
        User.full_name,
        func.avg(Result.percentage).label('avg_percentage')
    ).join(Result, Result.user_id == User.id) \
     .filter(User.role == 'student').group_by(User.id).order_by(func.avg(Result.percentage).desc()).limit(10).all()

    return render_template('admin_analytics.html',
                           enrollment_data=enrollment_data,
                           performance_data=performance_data)

@admin_bp.route('/assign-faculty/<int:request_id>', methods=['POST'])
@login_required
def assign_faculty(request_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))

    instructor_id = request.form.get('instructor_id')
    if not instructor_id:
        flash('Please select an instructor to assign.', 'warning')
        return redirect(url_for('admin.dashboard'))

    req = CourseRequest.query.get_or_404(request_id)
    course = Course(title=req.title, description=req.description or '', instructor_id=instructor_id, status='Approved')
    db.session.add(course)
    req.status = 'assigned'
    db.session.commit()

    flash('Faculty assigned and course published successfully!', 'success')
    return redirect(url_for('admin.dashboard'))
