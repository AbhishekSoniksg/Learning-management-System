from flask import Flask, render_template, redirect, url_for
from flask_login import current_user
import os

from extensions import db, login_manager, bcrypt
from models import User, Badge, CourseCategory, Notification
from datetime import datetime
from utils import create_notification, check_and_award_badges
import sqlite3
from sqlalchemy.engine.url import make_url

# Initialize extensions (Moved to extensions.py)

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = 'dev_secret_key_change_in_production' # fast dev key
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///lms.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Init extensions
    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'

    # Import and Register Blueprints
    from routes.auth_routes import auth_bp
    from routes.admin_routes import admin_bp
    from routes.instructor_routes import instructor_bp
    from routes.student_routes import student_bp
    from routes.main_routes import main_bp

    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(instructor_bp, url_prefix='/instructor')
    app.register_blueprint(student_bp, url_prefix='/student')
    app.register_blueprint(main_bp) # Root routes

    # Create Database Tables
    with app.app_context():
        import models # Import models to ensure they are registered
        ensure_sqlite_schema(app)
        db.create_all()
        seed_defaults()

    @app.context_processor
    def inject_unread_notifications():
        if current_user.is_authenticated:
            unread_notifications = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
        else:
            unread_notifications = 0
        return dict(unread_notifications=unread_notifications)

    return app

def ensure_sqlite_schema(app):
    db_uri = app.config.get('SQLALCHEMY_DATABASE_URI', '')
    if not db_uri.startswith('sqlite:'):
        return

    try:
        url = make_url(db_uri)
        db_path = url.database
    except Exception:
        return

    if not db_path:
        return

    candidate_paths = []
    if os.path.isabs(db_path):
        candidate_paths.append(db_path)
    else:
        candidate_paths.append(os.path.join(app.root_path, db_path))
        candidate_paths.append(os.path.join(app.instance_path, db_path))
        candidate_paths.append(os.path.join(os.getcwd(), db_path))

    db_path = next((p for p in candidate_paths if os.path.exists(p)), None)
    if not db_path:
        return

    try:
        conn = sqlite3.connect(db_path)
        columns = [row[1] for row in conn.execute('PRAGMA table_info(user)').fetchall()]
        conn.close()
    except Exception:
        return

    if 'full_name' not in columns:
        backup_path = db_path + '.bak'
        try:
            os.replace(db_path, backup_path)
        except Exception:
            pass

def seed_defaults():
    # Seed default admin
    if not User.query.filter_by(role='admin').first():
        admin_password = bcrypt.generate_password_hash('admin123').decode('utf-8')
        admin = User(
            name='System Administrator',
            full_name='System Administrator',
            email='admin@lms.com',
            password=admin_password,
            role='admin'
        )
        db.session.add(admin)
        db.session.commit()

    # Seed badges
    default_badges = [
        ('First Steps', 'Enrolled in your first course', '🎓', 'enroll_first_course'),
        ('Assessment Master', 'Scored 100% in an assessment', '🏆', 'perfect_score'),
        ('Active Learner', 'Completed 5 courses', '📚', 'complete_5_courses'),
        ('Discussion Leader', 'Created 10 forum threads', '💬', 'create_10_threads'),
        ('Perfect Attendance', 'Perfect attendance for 1 month', '✅', 'perfect_attendance')
    ]
    for name, description, icon, criteria in default_badges:
        if not Badge.query.filter_by(criteria=criteria).first():
            db.session.add(Badge(name=name, description=description, icon=icon, criteria=criteria))

    # Seed categories
    default_categories = [
        ('Computer Science', 'Programming, algorithms, and software development'),
        ('Mathematics', 'Pure and applied mathematics courses'),
        ('Business', 'Business administration, management, and finance'),
        ('Science', 'Natural sciences including physics, chemistry, biology'),
        ('Arts & Humanities', 'Literature, history, philosophy, and arts'),
        ('Engineering', 'Various engineering disciplines'),
        ('Languages', 'Foreign language learning'),
        ('Health & Medicine', 'Medical and health-related courses')
    ]
    for name, description in default_categories:
        if not CourseCategory.query.filter_by(name=name).first():
            db.session.add(CourseCategory(name=name, description=description))

    db.session.commit()


if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
