from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from datetime import datetime
import os

def generate_certificate(user, course, certificate):
    """Generate a PDF certificate for course completion"""
    
    # Create certificates directory if it doesn't exist
    os.makedirs('certificates', exist_ok=True)
    
    # Certificate filename
    filename = f"certificates/cert_{user.id}_{course.id}_{certificate.id}.pdf"
    
    # Create PDF document
    doc = SimpleDocTemplate(filename, pagesize=A4)
    story = []
    
    # Define styles
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#1a237e'),
        spaceAfter=30,
        alignment=1,  # Center alignment
        fontName='Helvetica-Bold'
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=18,
        textColor=colors.HexColor('#283593'),
        spaceAfter=20,
        alignment=1,
        fontName='Helvetica'
    )
    
    body_style = ParagraphStyle(
        'CustomBody',
        parent=styles['BodyText'],
        fontSize=14,
        textColor=colors.HexColor('#424242'),
        spaceAfter=12,
        alignment=1,
        fontName='Helvetica'
    )
    
    name_style = ParagraphStyle(
        'NameStyle',
        parent=styles['Heading2'],
        fontSize=20,
        textColor=colors.HexColor('#1976d2'),
        spaceAfter=30,
        alignment=1,
        fontName='Helvetica-Bold'
    )
    
    # Add content
    story.append(Spacer(1, 1.5*inch))
    
    # Certificate Title
    story.append(Paragraph("CERTIFICATE OF COMPLETION", title_style))
    story.append(Spacer(1, 0.3*inch))
    
    # Body text
    story.append(Paragraph("This is to certify that", body_style))
    story.append(Spacer(1, 0.2*inch))
    
    # Student name
    story.append(Paragraph(f"<b>{user.username}</b>", name_style))
    story.append(Spacer(1, 0.2*inch))
    
    # Course completion text
    story.append(Paragraph("has successfully completed the course", body_style))
    story.append(Spacer(1, 0.2*inch))
    
    # Course title
    story.append(Paragraph(f"<b>{course.title}</b>", heading_style))
    story.append(Spacer(1, 0.3*inch))
    
    # Date
    date_str = certificate.issued_date.strftime("%B %d, %Y")
    story.append(Paragraph(f"Date: {date_str}", body_style))
    story.append(Spacer(1, 1.5*inch))
    
    # Signature line (placeholder)
    story.append(Paragraph("_________________________", body_style))
    story.append(Paragraph("Instructor", body_style))
    
    # Build PDF
    doc.build(story)
    
    return filename
