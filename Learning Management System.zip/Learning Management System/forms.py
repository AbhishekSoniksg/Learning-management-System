from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, PasswordField, SelectField, IntegerField, RadioField
from wtforms.validators import DataRequired, Email, Length, NumberRange

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])

class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    role = SelectField('Role', choices=[('student', 'Student'), ('instructor', 'Instructor')], validators=[DataRequired()])

class CourseForm(FlaskForm):
    title = StringField('Course Title', validators=[DataRequired(), Length(max=200)])
    description = TextAreaField('Description', validators=[DataRequired()])
    category = SelectField('Category', choices=[
        ('General', 'General'),
        ('Programming', 'Programming'),
        ('Mathematics', 'Mathematics'),
        ('Science', 'Science'),
        ('Business', 'Business'),
        ('Design', 'Design'),
        ('Language', 'Language'),
        ('Other', 'Other')
    ], default='General', validators=[DataRequired()])

class MaterialForm(FlaskForm):
    title = StringField('Material Title', validators=[DataRequired(), Length(max=200)])
    content = TextAreaField('Content', validators=[DataRequired()])
    material_type = SelectField('Type', choices=[
        ('text', 'Text'),
        ('video', 'Video Link'),
        ('document', 'Document Link'),
        ('link', 'External Link')
    ], validators=[DataRequired()])

class AssessmentForm(FlaskForm):
    title = StringField('Assessment Title', validators=[DataRequired(), Length(max=200)])
    description = TextAreaField('Description')
    passing_score = IntegerField('Passing Score (%)', validators=[DataRequired(), NumberRange(min=0, max=100)], default=70)

class QuestionForm(FlaskForm):
    question_text = TextAreaField('Question', validators=[DataRequired()])
    option1 = StringField('Option 1', validators=[DataRequired()])
    option2 = StringField('Option 2', validators=[DataRequired()])
    option3 = StringField('Option 3', validators=[DataRequired()])
    option4 = StringField('Option 4', validators=[DataRequired()])
    correct_answer = RadioField('Correct Answer', choices=[
        (0, 'Option 1'),
        (1, 'Option 2'),
        (2, 'Option 3'),
        (3, 'Option 4')
    ], validators=[DataRequired()], coerce=int)
