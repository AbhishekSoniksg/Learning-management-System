from flask import Flask, render_template, request, redirect, url_for, flash, send_file
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User, Course, Material, Assessment, Question, Answer, Enrollment, Certificate, AssessmentResult
from forms import LoginForm, RegisterForm, CourseForm, MaterialForm, AssessmentForm, QuestionForm
from datetime import datetime
import os
from certificate import generate_certificate

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-change-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///lms.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads'

db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Create upload folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs('certificates', exist_ok=True)

# Initialize database
with app.app_context():
    db.create_all()
    # Create default admin if not exists
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(
            username='admin',
            email='admin@lms.com',
            password_hash=generate_password_hash('admin123'),
            role='admin',
            is_active=True
        )
        db.session.add(admin)
        db.session.commit()

# Routes
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user:
            flash('Username already exists', 'error')
            return render_template('register.html', form=form)
        
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            flash('Email already exists', 'error')
            return render_template('register.html', form=form)
        
        new_user = User(
            username=form.username.data,
            email=form.email.data,
            password_hash=generate_password_hash(form.password.data),
            role=form.role.data,
            is_active=True
        )
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if request.method == 'POST' and form.validate_on_submit():
        try:
            username = form.username.data.strip() if form.username.data else ''
            password = form.password.data if form.password.data else ''
            
            if not username or not password:
                flash('Please enter both username and password', 'error')
                return render_template('login.html', form=form)
            
            user = User.query.filter_by(username=username).first()
            if user and check_password_hash(user.password_hash, password):
                if user.is_active:
                    login_user(user, remember=False)
                    flash(f'Welcome, {user.username}!', 'success')
                    return redirect(url_for('dashboard'))
                else:
                    flash('Your account is inactive. Please contact admin.', 'error')
            else:
                flash('Invalid username or password', 'error')
        except Exception as e:
            flash('An error occurred during login. Please try again.', 'error')
            app.logger.error(f'Login error: {str(e)}')
            import traceback
            traceback.print_exc()
    elif request.method == 'POST':
        # Form validation failed
        flash('Please fill in all required fields', 'error')
    
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'admin':
        total_users = User.query.count()
        total_courses = Course.query.count()
        total_enrollments = Enrollment.query.count()
        pending_courses = Course.query.filter_by(is_approved=False).count()
        return render_template('admin_dashboard.html', 
                             total_users=total_users,
                             total_courses=total_courses,
                             total_enrollments=total_enrollments,
                             pending_courses=pending_courses)
    
    elif current_user.role == 'instructor':
        my_courses = Course.query.filter_by(instructor_id=current_user.id).all()
        total_students = Enrollment.query.join(Course).filter(Course.instructor_id == current_user.id).count()
        return render_template('instructor_dashboard.html', 
                             courses=my_courses,
                             total_students=total_students)
    
    else:  # student
        try:
            enrolled_courses = Enrollment.query.filter_by(student_id=current_user.id).all()
            course_list = [enrollment.course for enrollment in enrolled_courses if enrollment.course]
            available_courses = Course.query.filter_by(is_approved=True).all()
            available_courses = [c for c in available_courses if c not in course_list]
            
            # Calculate progress for enrolled courses (simplified to avoid hangs)
            course_progress = {}
            if course_list:
                for course in course_list:
                    try:
                        total = Assessment.query.filter_by(course_id=course.id).count()
                        completed = 0
                        if total > 0:
                            # Simple count of passed assessments
                            completed = db.session.query(AssessmentResult).join(
                                Assessment
                            ).filter(
                                AssessmentResult.student_id == current_user.id,
                                AssessmentResult.passed == True,
                                Assessment.course_id == course.id
                            ).count()
                        progress = (completed / total * 100) if total > 0 else 0
                        course_progress[course.id] = {
                            'completed': completed,
                            'total': total,
                            'percentage': progress
                        }
                    except Exception as e:
                        # If progress calculation fails, set defaults
                        course_progress[course.id] = {
                            'completed': 0,
                            'total': 0,
                            'percentage': 0
                        }
            
            return render_template('student_dashboard.html', 
                                 enrolled_courses=course_list,
                                 available_courses=available_courses,
                                 course_progress=course_progress)
        except Exception as e:
            app.logger.error(f'Dashboard error: {str(e)}')
            import traceback
            traceback.print_exc()
            flash('Error loading dashboard. Please try again.', 'error')
            return render_template('student_dashboard.html', 
                                 enrolled_courses=[],
                                 available_courses=[],
                                 course_progress={})

# Admin Routes
@app.route('/admin/users')
@login_required
def admin_users():
    if current_user.role != 'admin':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    users = User.query.all()
    return render_template('admin_users.html', users=users)

@app.route('/admin/courses')
@login_required
def admin_courses():
    if current_user.role != 'admin':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    courses = Course.query.all()
    return render_template('admin_courses.html', courses=courses)

@app.route('/admin/approve_course/<int:course_id>')
@login_required
def approve_course(course_id):
    if current_user.role != 'admin':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    course = Course.query.get_or_404(course_id)
    course.is_approved = True
    db.session.commit()
    flash('Course approved successfully', 'success')
    return redirect(url_for('admin_courses'))

@app.route('/admin/toggle_user/<int:user_id>')
@login_required
def toggle_user(user_id):
    if current_user.role != 'admin':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    user = User.query.get_or_404(user_id)
    user.is_active = not user.is_active
    db.session.commit()
    flash(f'User {"activated" if user.is_active else "deactivated"}', 'success')
    return redirect(url_for('admin_users'))

# Instructor Routes
@app.route('/instructor/create_course', methods=['GET', 'POST'])
@login_required
def create_course():
    if current_user.role != 'instructor':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    form = CourseForm()
    if form.validate_on_submit():
        course = Course(
            title=form.title.data,
            description=form.description.data,
            category=form.category.data,
            instructor_id=current_user.id,
            is_approved=False
        )
        db.session.add(course)
        db.session.commit()
        flash('Course created! Waiting for admin approval.', 'success')
        return redirect(url_for('dashboard'))
    return render_template('create_course.html', form=form)

@app.route('/instructor/course/<int:course_id>')
@login_required
def instructor_course(course_id):
    if current_user.role != 'instructor':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    course = Course.query.get_or_404(course_id)
    if course.instructor_id != current_user.id:
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    materials = Material.query.filter_by(course_id=course_id).all()
    assessments = Assessment.query.filter_by(course_id=course_id).all()
    return render_template('instructor_course.html', 
                         course=course, 
                         materials=materials, 
                         assessments=assessments)

@app.route('/instructor/add_material/<int:course_id>', methods=['GET', 'POST'])
@login_required
def add_material(course_id):
    if current_user.role != 'instructor':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    course = Course.query.get_or_404(course_id)
    if course.instructor_id != current_user.id:
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    form = MaterialForm()
    if form.validate_on_submit():
        material = Material(
            title=form.title.data,
            content=form.content.data,
            material_type=form.material_type.data,
            course_id=course_id
        )
        db.session.add(material)
        db.session.commit()
        flash('Material added successfully', 'success')
        return redirect(url_for('instructor_course', course_id=course_id))
    return render_template('add_material.html', form=form, course=course)

@app.route('/instructor/create_assessment/<int:course_id>', methods=['GET', 'POST'])
@login_required
def create_assessment(course_id):
    if current_user.role != 'instructor':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    course = Course.query.get_or_404(course_id)
    if course.instructor_id != current_user.id:
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    form = AssessmentForm()
    if form.validate_on_submit():
        assessment = Assessment(
            title=form.title.data,
            description=form.description.data,
            course_id=course_id,
            passing_score=form.passing_score.data
        )
        db.session.add(assessment)
        db.session.commit()
        flash('Assessment created! Now add questions.', 'success')
        return redirect(url_for('add_questions', assessment_id=assessment.id))
    return render_template('create_assessment.html', form=form, course=course)

@app.route('/instructor/add_questions/<int:assessment_id>', methods=['GET', 'POST'])
@login_required
def add_questions(assessment_id):
    if current_user.role != 'instructor':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    assessment = Assessment.query.get_or_404(assessment_id)
    course = Course.query.get_or_404(assessment.course_id)
    if course.instructor_id != current_user.id:
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    form = QuestionForm()
    if form.validate_on_submit():
        question = Question(
            question_text=form.question_text.data,
            assessment_id=assessment_id
        )
        db.session.add(question)
        db.session.flush()
        
        # Add answers
        correct_answer = int(form.correct_answer.data)
        for i, option in enumerate([form.option1.data, form.option2.data, form.option3.data, form.option4.data]):
            answer = Answer(
                answer_text=option,
                is_correct=(i == correct_answer),
                question_id=question.id
            )
            db.session.add(answer)
        db.session.commit()
        flash('Question added successfully', 'success')
        return redirect(url_for('add_questions', assessment_id=assessment_id))
    
    questions = Question.query.filter_by(assessment_id=assessment_id).all()
    return render_template('add_questions.html', form=form, assessment=assessment, questions=questions)

# Student Routes
@app.route('/student/enroll/<int:course_id>')
@login_required
def enroll_course(course_id):
    if current_user.role != 'student':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    course = Course.query.get_or_404(course_id)
    if not course.is_approved:
        flash('Course is not available yet', 'error')
        return redirect(url_for('dashboard'))
    
    existing = Enrollment.query.filter_by(student_id=current_user.id, course_id=course_id).first()
    if existing:
        flash('You are already enrolled in this course', 'info')
        return redirect(url_for('dashboard'))
    
    enrollment = Enrollment(student_id=current_user.id, course_id=course_id)
    db.session.add(enrollment)
    db.session.commit()
    flash(f'Successfully enrolled in {course.title}', 'success')
    return redirect(url_for('dashboard'))

@app.route('/student/course/<int:course_id>')
@login_required
def student_course(course_id):
    if current_user.role != 'student':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    course = Course.query.get_or_404(course_id)
    enrollment = Enrollment.query.filter_by(student_id=current_user.id, course_id=course_id).first()
    if not enrollment:
        flash('You are not enrolled in this course', 'error')
        return redirect(url_for('dashboard'))
    
    materials = Material.query.filter_by(course_id=course_id).all()
    assessments = Assessment.query.filter_by(course_id=course_id).all()
    cert = Certificate.query.filter_by(student_id=current_user.id, course_id=course_id).first()
    return render_template('student_course.html', 
                         course=course, 
                         materials=materials, 
                         assessments=assessments,
                         cert=cert)

@app.route('/student/take_assessment/<int:assessment_id>', methods=['GET', 'POST'])
@login_required
def take_assessment(assessment_id):
    if current_user.role != 'student':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    assessment = Assessment.query.get_or_404(assessment_id)
    course = Course.query.get_or_404(assessment.course_id)
    enrollment = Enrollment.query.filter_by(student_id=current_user.id, course_id=course.id).first()
    if not enrollment:
        flash('You are not enrolled in this course', 'error')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        questions = Question.query.filter_by(assessment_id=assessment_id).all()
        score = 0
        total = len(questions)
        
        for question in questions:
            selected_answer_id = request.form.get(f'question_{question.id}')
            if selected_answer_id:
                answer = Answer.query.get(int(selected_answer_id))
                if answer and answer.is_correct:
                    score += 1
        
        percentage = (score / total * 100) if total > 0 else 0
        passed = percentage >= assessment.passing_score
        
        # Save assessment result
        result = AssessmentResult(
            student_id=current_user.id,
            assessment_id=assessment_id,
            score=score,
            total_questions=total,
            percentage=percentage,
            passed=passed
        )
        db.session.add(result)
        db.session.commit()
        
        # Check if certificate should be generated
        if passed:
            # Check if all assessments are passed
            all_assessments = Assessment.query.filter_by(course_id=course.id).all()
            all_passed = True
            for ass in all_assessments:
                if ass.id == assessment_id:
                    continue
                # Check if student passed all other assessments
                other_result = AssessmentResult.query.filter_by(
                    student_id=current_user.id,
                    assessment_id=ass.id,
                    passed=True
                ).first()
                if not other_result:
                    all_passed = False
                    break
            
            # Generate certificate if all assessments passed
            if all_passed:
                cert = Certificate.query.filter_by(student_id=current_user.id, course_id=course.id).first()
                if not cert:
                    cert = Certificate(
                        student_id=current_user.id,
                        course_id=course.id,
                        issued_date=datetime.now()
                    )
                    db.session.add(cert)
                    db.session.commit()
        
        cert = Certificate.query.filter_by(student_id=current_user.id, course_id=course.id).first() if passed else None
        return render_template('assessment_result.html', 
                             assessment=assessment,
                             score=score,
                             total=total,
                             percentage=percentage,
                             passed=passed,
                             course=course,
                             cert=cert)
    
    questions = Question.query.filter_by(assessment_id=assessment_id).all()
    question_data = []
    for question in questions:
        answers = Answer.query.filter_by(question_id=question.id).all()
        question_data.append({'question': question, 'answers': answers})
    
    return render_template('take_assessment.html', 
                         assessment=assessment, 
                         questions=question_data)

@app.route('/student/certificate/<int:course_id>')
@login_required
def download_certificate(course_id):
    if current_user.role != 'student':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    course = Course.query.get_or_404(course_id)
    cert = Certificate.query.filter_by(student_id=current_user.id, course_id=course_id).first()
    if not cert:
        flash('Certificate not available', 'error')
        return redirect(url_for('dashboard'))
    
    cert_path = generate_certificate(current_user, course, cert)
    return send_file(cert_path, as_attachment=True, download_name=f'certificate_{course.title.replace(" ", "_")}.pdf')

@app.route('/search')
@login_required
def search():
    query = request.args.get('q', '').strip()
    category = request.args.get('category', '')
    
    if current_user.role == 'student':
        courses = Course.query.filter_by(is_approved=True)
        if query:
            courses = courses.filter(
                (Course.title.contains(query)) | 
                (Course.description.contains(query))
            )
        if category:
            courses = courses.filter_by(category=category)
        courses = courses.all()
    else:
        courses = Course.query.all()
        if query:
            courses = [c for c in courses if query.lower() in c.title.lower() or query.lower() in c.description.lower()]
    
    categories = db.session.query(Course.category).distinct().all()
    categories = [cat[0] for cat in categories if cat[0]]
    
    return render_template('search_results.html', 
                         courses=courses, 
                         query=query, 
                         category=category,
                         categories=categories)

@app.route('/student/assessment_history')
@login_required
def assessment_history():
    if current_user.role != 'student':
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    results = AssessmentResult.query.filter_by(student_id=current_user.id).order_by(AssessmentResult.completed_at.desc()).all()
    return render_template('assessment_history.html', results=results)

if __name__ == '__main__':
    app.run(debug=True)
