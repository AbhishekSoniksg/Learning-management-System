"""
Script to reset the database with new schema
Run this once to update your database with new fields
"""
from app import app, db
from models import User, Course, Material, Assessment, Question, Answer, Enrollment, Certificate, AssessmentResult
from werkzeug.security import generate_password_hash

with app.app_context():
    # Drop all tables
    print("Dropping all tables...")
    db.drop_all()
    
    # Create all tables with new schema
    print("Creating tables with new schema...")
    db.create_all()
    
    # Recreate default admin
    print("Creating default admin account...")
    admin = User(
        username='admin',
        email='admin@lms.com',
        password_hash=generate_password_hash('admin123'),
        role='admin',
        is_active=True
    )
    db.session.add(admin)
    db.session.commit()
    
    print("Database reset complete!")
    print("Default admin credentials:")
    print("  Username: admin")
    print("  Password: admin123")
