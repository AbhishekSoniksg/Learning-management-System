// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// Auto-hide flash messages
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
});

// Progress bar animation
document.addEventListener('DOMContentLoaded', function() {
    const progressBars = document.querySelectorAll('.progress-fill');
    progressBars.forEach(bar => {
        const width = bar.style.width;
        bar.style.width = '0%';
        setTimeout(() => {
            bar.style.transition = 'width 1s ease-in-out';
            bar.style.width = width;
        }, 100);
    });
});

// Course card hover effects
document.addEventListener('DOMContentLoaded', function() {
    const courseCards = document.querySelectorAll('.course-card');
    courseCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.transition = 'transform 0.3s ease';
        });
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
});

// Search form enhancement
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.querySelector('.search-input');
    if (searchInput) {
        searchInput.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        searchInput.addEventListener('blur', function() {
            this.parentElement.classList.remove('focused');
        });
    }
});

// Assessment form validation
document.addEventListener('DOMContentLoaded', function() {
    const assessmentForm = document.querySelector('.assessment-form');
    if (assessmentForm) {
        assessmentForm.addEventListener('submit', function(e) {
            const questions = this.querySelectorAll('.question-block');
            let allAnswered = true;
            
            questions.forEach(question => {
                const radios = question.querySelectorAll('input[type="radio"]');
                const checked = Array.from(radios).some(radio => radio.checked);
                if (!checked) {
                    allAnswered = false;
                    question.style.border = '2px solid #e74c3c';
                    setTimeout(() => {
                        question.style.border = '';
                    }, 2000);
                }
            });
            
            if (!allAnswered) {
                e.preventDefault();
                alert('Please answer all questions before submitting.');
            }
        });
    }
});

// Answer option selection feedback
document.addEventListener('DOMContentLoaded', function() {
    const answerOptions = document.querySelectorAll('.answer-option');
    answerOptions.forEach(option => {
        option.addEventListener('click', function() {
            const questionBlock = this.closest('.question-block');
            const allOptions = questionBlock.querySelectorAll('.answer-option');
            allOptions.forEach(opt => opt.classList.remove('selected'));
            this.classList.add('selected');
        });
    });
});

// Statistics counter animation
function animateCounter(element, target, duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16);
    const timer = setInterval(() => {
        start += increment;
        if (start >= target) {
            element.textContent = Math.round(target);
            clearInterval(timer);
        } else {
            element.textContent = Math.round(start);
        }
    }, 16);
}

document.addEventListener('DOMContentLoaded', function() {
    const statNumbers = document.querySelectorAll('.stat-info h3');
    statNumbers.forEach(stat => {
        const target = parseInt(stat.textContent);
        if (!isNaN(target) && target > 0) {
            stat.textContent = '0';
            setTimeout(() => animateCounter(stat, target), 200);
        }
    });
});

// Tab switching with animation
function showTab(tabName) {
    const tabs = ['materials', 'assessments'];
    tabs.forEach(tab => {
        const tabContent = document.getElementById(tab);
        const tabButton = document.querySelector(`.tab-button[onclick*="${tab}"]`);
        if (tabContent) {
            tabContent.classList.remove('active');
            tabContent.style.opacity = '0';
        }
        if (tabButton) {
            tabButton.classList.remove('active');
        }
    });
    
    const activeTab = document.getElementById(tabName);
    const activeButton = document.querySelector(`.tab-button[onclick*="${tabName}"]`);
    
    if (activeTab) {
        setTimeout(() => {
            activeTab.classList.add('active');
            activeTab.style.transition = 'opacity 0.3s';
            activeTab.style.opacity = '1';
        }, 50);
    }
    if (activeButton) {
        activeButton.classList.add('active');
    }
}

// Material type icons
document.addEventListener('DOMContentLoaded', function() {
    const materialCards = document.querySelectorAll('.material-card');
    materialCards.forEach(card => {
        card.addEventListener('click', function() {
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    });
});

// Loading animation
function showLoader() {
    const loader = document.createElement('div');
    loader.className = 'page-loader';
    loader.innerHTML = '<div class="spinner"></div>';
    document.body.appendChild(loader);
}

function hideLoader() {
    const loader = document.querySelector('.page-loader');
    if (loader) {
        loader.remove();
    }
}

// Form submission loading (exclude login form to avoid conflicts)
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form:not(#loginForm)');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitBtn = this.querySelector('button[type="submit"]');
            if (submitBtn && !submitBtn.disabled) {
                const originalText = submitBtn.innerHTML;
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
                
                // Reset button after 10 seconds if page doesn't reload (error case)
                setTimeout(() => {
                    if (submitBtn.disabled) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalText;
                    }
                }, 10000);
            }
        });
    });
});
