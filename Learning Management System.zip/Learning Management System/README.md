# Learning Management System (LMS)

A full-featured Learning Management System built with Flask and SQLite, featuring role-based access control for Admin, Instructor, and Student roles.

## Features

- **Role-Based Access Control**: Three distinct roles (Admin, Instructor, Student) with appropriate permissions
- **Course Management**: Instructors can create courses that require admin approval
- **Course Materials**: Support for text, video links, document links, and external links
- **MCQ Assessments**: Create and take multiple-choice question assessments
- **Certificate Generation**: Automatic PDF certificate generation upon course completion
- **Dashboard**: Role-specific dashboards with relevant information
- **User Management**: Admin can manage users and approve courses
- **Modern UI**: Beautiful, responsive design with Font Awesome icons

## Installation

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run the Application**
   ```bash
   python app.py
   ```

3. **Access the Application**
   - Open your browser and navigate to `http://localhost:5000`

## Default Credentials

- **Admin Account:**
  - Username: `admin`
  - Password: `admin123`

## User Roles

### Admin
- View system statistics (total users, courses, enrollments)
- Manage users (activate/deactivate accounts)
- Approve/reject courses created by instructors
- Full system access

### Instructor
- Create courses (pending admin approval)
- Add course materials (text, videos, documents, links)
- Create assessments with MCQ questions
- View enrolled students
- Manage their own courses

### Student
- Browse available courses
- Enroll in courses
- View course materials
- Take assessments
- Download certificates upon completion

## Project Structure

```
Learning Management System/
├── app.py                 # Main Flask application
├── models.py              # Database models
├── forms.py               # WTForms form definitions
├── certificate.py         # PDF certificate generation
├── requirements.txt       # Python dependencies
├── templates/            # HTML templates
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── admin_dashboard.html
│   ├── instructor_dashboard.html
│   ├── student_dashboard.html
│   └── ... (other templates)
├── static/               # Static files
│   └── style.css        # CSS styles
├── uploads/              # Uploaded files (created automatically)
├── certificates/         # Generated certificates (created automatically)
└── lms.db               # SQLite database (created automatically)
```

## Usage Guide

### For Students:
1. Register as a student
2. Browse available courses on the dashboard
3. Enroll in courses
4. Access course materials
5. Take assessments
6. Download certificates after passing assessments

### For Instructors:
1. Register as an instructor
2. Create courses (wait for admin approval)
3. Add materials to your courses
4. Create assessments with MCQ questions
5. View student enrollments

### For Admins:
1. Login with admin credentials
2. View system overview on dashboard
3. Approve pending courses
4. Manage user accounts (activate/deactivate)
5. Monitor system statistics

## Database Models

- **User**: Stores user information and roles
- **Course**: Course details and instructor relationship
- **Material**: Course materials (text, videos, documents, links)
- **Assessment**: Assessment information with passing scores
- **Question**: MCQ questions for assessments
- **Answer**: Answer options for questions
- **Enrollment**: Student-course enrollment records
- **Certificate**: Certificate records for completed courses

## Technologies Used

- **Flask**: Web framework
- **SQLite**: Database
- **Flask-Login**: User session management
- **Flask-WTF**: Form handling
- **WTForms**: Form validation
- **ReportLab**: PDF certificate generation
- **Font Awesome**: Icons

## Notes

- The database is automatically created on first run
- Default admin account is created automatically
- Certificates are generated as PDF files
- All passwords are hashed using Werkzeug
- Course materials support various types (text, video, document, link)

## Future Enhancements

- File upload functionality for course materials
- Progress tracking for students
- Discussion forums
- Email notifications
- Advanced analytics
- Multi-language support

## License

This project is open source and available for educational purposes.
