from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import sqlite3
import hashlib
import os
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = 'your_secret_key_here_change_in_production'

# Database initialization
def init_db():
    # Create data directory if it doesn't exist
    if not os.path.exists('data'):
        os.makedirs('data')
    
    conn = sqlite3.connect('data/lms.db')
    c = conn.cursor()
    
    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        role TEXT NOT NULL,
        full_name TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'active'
    )''')
    
    # Courses table
    c.execute('''CREATE TABLE IF NOT EXISTS courses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        instructor_id INTEGER,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (instructor_id) REFERENCES users(id)
    )''')
    
    # Course materials table
    c.execute('''CREATE TABLE IF NOT EXISTS course_materials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER,
        title TEXT NOT NULL,
        content TEXT,
        file_path TEXT,
        material_type TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id)
    )''')
    
    # Enrollments table
    c.execute('''CREATE TABLE IF NOT EXISTS enrollments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER,
        course_id INTEGER,
        enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users(id),
        FOREIGN KEY (course_id) REFERENCES courses(id)
    )''')
    
    # Assessments table
    c.execute('''CREATE TABLE IF NOT EXISTS assessments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER,
        title TEXT NOT NULL,
        description TEXT,
        total_marks INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id)
    )''')
    
    # Questions table
    c.execute('''CREATE TABLE IF NOT EXISTS questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        assessment_id INTEGER,
        question_text TEXT NOT NULL,
        option_a TEXT,
        option_b TEXT,
        option_c TEXT,
        option_d TEXT,
        correct_answer TEXT,
        marks INTEGER DEFAULT 1,
        FOREIGN KEY (assessment_id) REFERENCES assessments(id)
    )''')
    
    # Results table
    c.execute('''CREATE TABLE IF NOT EXISTS results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER,
        assessment_id INTEGER,
        score INTEGER,
        total_marks INTEGER,
        percentage REAL,
        feedback TEXT,
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users(id),
        FOREIGN KEY (assessment_id) REFERENCES assessments(id)
    )''')
    
    # Assignments table
    c.execute('''CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER,
        title TEXT NOT NULL,
        description TEXT,
        due_date DATE,
        total_marks INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id)
    )''')
    
    # Assignment submissions table
    c.execute('''CREATE TABLE IF NOT EXISTS assignment_submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        assignment_id INTEGER,
        student_id INTEGER,
        submission_text TEXT,
        file_path TEXT,
        score INTEGER,
        feedback TEXT,
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (assignment_id) REFERENCES assignments(id),
        FOREIGN KEY (student_id) REFERENCES users(id)
    )''')
    
    # Create default admin user
    try:
        password_hash = hashlib.sha256('admin123'.encode()).hexdigest()
        c.execute('''INSERT INTO users (username, password, email, role, full_name) 
                     VALUES (?, ?, ?, ?, ?)''',
                  ('admin', password_hash, 'admin@lms.com', 'admin', 'System Administrator'))
    except sqlite3.IntegrityError:
        pass  # Admin already exists
    
    conn.commit()
    conn.close()

# Initialize database on startup
init_db()

# Database helper functions
def get_db():
    conn = sqlite3.connect('data/lms.db')
    conn.row_factory = sqlite3.Row
    return conn

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Role required decorator
def role_required(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'role' not in session or session['role'] != role:
                flash('You do not have permission to access this page.', 'danger')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# Routes

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?',
                           (username, password_hash)).fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            session['full_name'] = user['full_name']
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        full_name = request.form['full_name']
        role = request.form.get('role', 'student')
        
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        conn = get_db()
        try:
            conn.execute('''INSERT INTO users (username, password, email, role, full_name) 
                           VALUES (?, ?, ?, ?, ?)''',
                        (username, password_hash, email, role, full_name))
            conn.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username or email already exists', 'danger')
        finally:
            conn.close()
    
    return render_template('register.html')

@app.route('/dashboard')
@login_required
def dashboard():
    role = session.get('role')
    
    if role == 'admin':
        return redirect(url_for('admin_dashboard'))
    elif role == 'instructor':
        return redirect(url_for('instructor_dashboard'))
    else:
        return redirect(url_for('student_dashboard'))

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

# ========== ADMIN MODULE ==========

@app.route('/admin/dashboard')
@login_required
@role_required('admin')
def admin_dashboard():
    conn = get_db()
    
    # Get statistics
    total_users = conn.execute('SELECT COUNT(*) as count FROM users').fetchone()['count']
    total_students = conn.execute('SELECT COUNT(*) as count FROM users WHERE role = "student"').fetchone()['count']
    total_instructors = conn.execute('SELECT COUNT(*) as count FROM users WHERE role = "instructor"').fetchone()['count']
    total_courses = conn.execute('SELECT COUNT(*) as count FROM courses').fetchone()['count']
    pending_courses = conn.execute('SELECT COUNT(*) as count FROM courses WHERE status = "pending"').fetchone()['count']
    
    # Get recent users
    recent_users = conn.execute('SELECT * FROM users ORDER BY created_at DESC LIMIT 5').fetchall()
    
    # Get pending courses
    pending_courses_list = conn.execute('''
        SELECT c.*, u.full_name as instructor_name 
        FROM courses c
        JOIN users u ON c.instructor_id = u.id
        WHERE c.status = "pending"
        ORDER BY c.created_at DESC
    ''').fetchall()
    
    conn.close()
    
    return render_template('admin_dashboard.html',
                         total_users=total_users,
                         total_students=total_students,
                         total_instructors=total_instructors,
                         total_courses=total_courses,
                         pending_courses=pending_courses,
                         recent_users=recent_users,
                         pending_courses_list=pending_courses_list)

@app.route('/admin/users')
@login_required
@role_required('admin')
def admin_users():
    conn = get_db()
    users = conn.execute('SELECT * FROM users ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('admin_users.html', users=users)

@app.route('/admin/approve_course/<int:course_id>')
@login_required
@role_required('admin')
def approve_course(course_id):
    conn = get_db()
    conn.execute('UPDATE courses SET status = "approved" WHERE id = ?', (course_id,))
    conn.commit()
    conn.close()
    flash('Course approved successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/reject_course/<int:course_id>')
@login_required
@role_required('admin')
def reject_course(course_id):
    conn = get_db()
    conn.execute('UPDATE courses SET status = "rejected" WHERE id = ?', (course_id,))
    conn.commit()
    conn.close()
    flash('Course rejected.', 'info')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/analytics')
@login_required
@role_required('admin')
def admin_analytics():
    conn = get_db()
    
    # Get various analytics data
    enrollment_data = conn.execute('''
        SELECT c.title, COUNT(e.id) as count
        FROM courses c
        LEFT JOIN enrollments e ON c.id = e.course_id
        WHERE c.status = "approved"
        GROUP BY c.id
        ORDER BY count DESC
        LIMIT 10
    ''').fetchall()
    
    # Get performance data
    performance_data = conn.execute('''
        SELECT u.full_name, AVG(r.percentage) as avg_percentage
        FROM users u
        JOIN results r ON u.id = r.student_id
        WHERE u.role = "student"
        GROUP BY u.id
        ORDER BY avg_percentage DESC
        LIMIT 10
    ''').fetchall()
    
    conn.close()
    
    return render_template('admin_analytics.html',
                         enrollment_data=enrollment_data,
                         performance_data=performance_data)

# ========== INSTRUCTOR MODULE ==========

@app.route('/instructor/dashboard')
@login_required
@role_required('instructor')
def instructor_dashboard():
    conn = get_db()
    
    instructor_id = session['user_id']
    
    # Get instructor's courses
    courses = conn.execute('SELECT * FROM courses WHERE instructor_id = ? ORDER BY created_at DESC',
                          (instructor_id,)).fetchall()
    
    # Get statistics
    total_courses = len(courses)
    approved_courses = len([c for c in courses if c['status'] == 'approved'])
    
    total_students = conn.execute('''
        SELECT COUNT(DISTINCT e.student_id) as count
        FROM enrollments e
        JOIN courses c ON e.course_id = c.id
        WHERE c.instructor_id = ?
    ''', (instructor_id,)).fetchone()['count']
    
    conn.close()
    
    return render_template('instructor_dashboard.html',
                         courses=courses,
                         total_courses=total_courses,
                         approved_courses=approved_courses,
                         total_students=total_students)

@app.route('/instructor/create_course', methods=['GET', 'POST'])
@login_required
@role_required('instructor')
def create_course():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        instructor_id = session['user_id']
        
        conn = get_db()
        conn.execute('INSERT INTO courses (title, description, instructor_id) VALUES (?, ?, ?)',
                    (title, description, instructor_id))
        conn.commit()
        conn.close()
        
        flash('Course created successfully! Waiting for admin approval.', 'success')
        return redirect(url_for('instructor_dashboard'))
    
    return render_template('create_course.html')

@app.route('/instructor/course/<int:course_id>')
@login_required
@role_required('instructor')
def instructor_course_details(course_id):
    conn = get_db()
    
    course = conn.execute('SELECT * FROM courses WHERE id = ? AND instructor_id = ?',
                         (course_id, session['user_id'])).fetchone()
    
    if not course:
        flash('Course not found or access denied.', 'danger')
        return redirect(url_for('instructor_dashboard'))
    
    materials = conn.execute('SELECT * FROM course_materials WHERE course_id = ? ORDER BY created_at DESC',
                            (course_id,)).fetchall()
    
    assessments = conn.execute('SELECT * FROM assessments WHERE course_id = ? ORDER BY created_at DESC',
                              (course_id,)).fetchall()
    
    assignments = conn.execute('SELECT * FROM assignments WHERE course_id = ? ORDER BY created_at DESC',
                              (course_id,)).fetchall()
    
    students = conn.execute('''
        SELECT u.*, e.enrolled_at
        FROM users u
        JOIN enrollments e ON u.id = e.student_id
        WHERE e.course_id = ?
        ORDER BY e.enrolled_at DESC
    ''', (course_id,)).fetchall()
    
    conn.close()
    
    return render_template('instructor_course_details.html',
                         course=course,
                         materials=materials,
                         assessments=assessments,
                         assignments=assignments,
                         students=students)

@app.route('/instructor/add_material/<int:course_id>', methods=['POST'])
@login_required
@role_required('instructor')
def add_material(course_id):
    title = request.form['title']
    content = request.form['content']
    material_type = request.form['material_type']
    
    conn = get_db()
    conn.execute('''INSERT INTO course_materials (course_id, title, content, material_type)
                   VALUES (?, ?, ?, ?)''',
                (course_id, title, content, material_type))
    conn.commit()
    conn.close()
    
    flash('Material added successfully!', 'success')
    return redirect(url_for('instructor_course_details', course_id=course_id))

@app.route('/instructor/create_assessment/<int:course_id>', methods=['GET', 'POST'])
@login_required
@role_required('instructor')
def create_assessment(course_id):
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        total_marks = request.form['total_marks']
        
        conn = get_db()
        cursor = conn.execute('''INSERT INTO assessments (course_id, title, description, total_marks)
                               VALUES (?, ?, ?, ?)''',
                            (course_id, title, description, total_marks))
        assessment_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        flash('Assessment created! Now add questions.', 'success')
        return redirect(url_for('add_questions', assessment_id=assessment_id))
    
    conn = get_db()
    course = conn.execute('SELECT * FROM courses WHERE id = ?', (course_id,)).fetchone()
    conn.close()
    
    return render_template('create_assessment.html', course=course)

@app.route('/instructor/add_questions/<int:assessment_id>', methods=['GET', 'POST'])
@login_required
@role_required('instructor')
def add_questions(assessment_id):
    if request.method == 'POST':
        question_text = request.form['question_text']
        option_a = request.form['option_a']
        option_b = request.form['option_b']
        option_c = request.form['option_c']
        option_d = request.form['option_d']
        correct_answer = request.form['correct_answer']
        marks = request.form['marks']
        
        conn = get_db()
        conn.execute('''INSERT INTO questions 
                       (assessment_id, question_text, option_a, option_b, option_c, option_d, correct_answer, marks)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                    (assessment_id, question_text, option_a, option_b, option_c, option_d, correct_answer, marks))
        conn.commit()
        conn.close()
        
        flash('Question added successfully!', 'success')
        
        if 'add_another' in request.form:
            return redirect(url_for('add_questions', assessment_id=assessment_id))
        else:
            return redirect(url_for('instructor_dashboard'))
    
    conn = get_db()
    assessment = conn.execute('''
        SELECT a.*, c.title as course_title
        FROM assessments a
        JOIN courses c ON a.course_id = c.id
        WHERE a.id = ?
    ''', (assessment_id,)).fetchone()
    
    questions = conn.execute('SELECT * FROM questions WHERE assessment_id = ?',
                            (assessment_id,)).fetchall()
    conn.close()
    
    return render_template('add_questions.html', assessment=assessment, questions=questions)

@app.route('/instructor/student_performance/<int:course_id>')
@login_required
@role_required('instructor')
def student_performance(course_id):
    conn = get_db()
    
    # Get all students enrolled in the course with their performance
    performance = conn.execute('''
        SELECT 
            u.id, u.full_name, u.email,
            AVG(r.percentage) as avg_percentage,
            COUNT(DISTINCT r.assessment_id) as assessments_taken
        FROM users u
        JOIN enrollments e ON u.id = e.student_id
        LEFT JOIN results r ON u.id = r.student_id
        LEFT JOIN assessments a ON r.assessment_id = a.id
        WHERE e.course_id = ? AND u.role = "student"
        GROUP BY u.id
        ORDER BY avg_percentage DESC
    ''', (course_id,)).fetchall()
    
    course = conn.execute('SELECT * FROM courses WHERE id = ?', (course_id,)).fetchone()
    
    conn.close()
    
    return render_template('student_performance.html', performance=performance, course=course)

# ========== STUDENT MODULE ==========

@app.route('/student/dashboard')
@login_required
@role_required('student')
def student_dashboard():
    conn = get_db()
    
    student_id = session['user_id']
    
    # Get enrolled courses
    enrolled_courses = conn.execute('''
        SELECT c.*, e.enrolled_at
        FROM courses c
        JOIN enrollments e ON c.id = e.course_id
        WHERE e.student_id = ? AND c.status = "approved"
        ORDER BY e.enrolled_at DESC
    ''', (student_id,)).fetchall()
    
    # Get available courses (not enrolled)
    available_courses = conn.execute('''
        SELECT c.*, u.full_name as instructor_name
        FROM courses c
        JOIN users u ON c.instructor_id = u.id
        WHERE c.status = "approved" 
        AND c.id NOT IN (
            SELECT course_id FROM enrollments WHERE student_id = ?
        )
        ORDER BY c.created_at DESC
    ''', (student_id,)).fetchall()
    
    # Get recent results
    recent_results = conn.execute('''
        SELECT r.*, a.title as assessment_title, c.title as course_title
        FROM results r
        JOIN assessments a ON r.assessment_id = a.id
        JOIN courses c ON a.course_id = c.id
        WHERE r.student_id = ?
        ORDER BY r.submitted_at DESC
        LIMIT 5
    ''', (student_id,)).fetchall()
    
    conn.close()
    
    return render_template('student_dashboard.html',
                         enrolled_courses=enrolled_courses,
                         available_courses=available_courses,
                         recent_results=recent_results)

@app.route('/student/enroll/<int:course_id>')
@login_required
@role_required('student')
def enroll_course(course_id):
    conn = get_db()
    
    # Check if already enrolled
    existing = conn.execute('SELECT * FROM enrollments WHERE student_id = ? AND course_id = ?',
                           (session['user_id'], course_id)).fetchone()
    
    if existing:
        flash('You are already enrolled in this course.', 'info')
    else:
        conn.execute('INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)',
                    (session['user_id'], course_id))
        conn.commit()
        flash('Successfully enrolled in the course!', 'success')
    
    conn.close()
    return redirect(url_for('student_dashboard'))

@app.route('/student/course/<int:course_id>')
@login_required
@role_required('student')
def student_course_view(course_id):
    conn = get_db()
    
    # Check if student is enrolled
    enrollment = conn.execute('SELECT * FROM enrollments WHERE student_id = ? AND course_id = ?',
                             (session['user_id'], course_id)).fetchone()
    
    if not enrollment:
        flash('You are not enrolled in this course.', 'danger')
        return redirect(url_for('student_dashboard'))
    
    course = conn.execute('''
        SELECT c.*, u.full_name as instructor_name
        FROM courses c
        JOIN users u ON c.instructor_id = u.id
        WHERE c.id = ?
    ''', (course_id,)).fetchone()
    
    materials = conn.execute('SELECT * FROM course_materials WHERE course_id = ? ORDER BY created_at DESC',
                            (course_id,)).fetchall()
    
    assessments = conn.execute('SELECT * FROM assessments WHERE course_id = ? ORDER BY created_at DESC',
                              (course_id,)).fetchall()
    
    # Get student's results for this course
    results = conn.execute('''
        SELECT r.*, a.title as assessment_title
        FROM results r
        JOIN assessments a ON r.assessment_id = a.id
        WHERE r.student_id = ? AND a.course_id = ?
    ''', (session['user_id'], course_id)).fetchall()
    
    conn.close()
    
    return render_template('student_course_view.html',
                         course=course,
                         materials=materials,
                         assessments=assessments,
                         results=results)

@app.route('/student/take_assessment/<int:assessment_id>', methods=['GET', 'POST'])
@login_required
@role_required('student')
def take_assessment(assessment_id):
    conn = get_db()
    
    if request.method == 'POST':
        # Calculate score
        questions = conn.execute('SELECT * FROM questions WHERE assessment_id = ?',
                                (assessment_id,)).fetchall()
        
        score = 0
        total_marks = 0
        
        for question in questions:
            total_marks += question['marks']
            user_answer = request.form.get(f'question_{question["id"]}')
            if user_answer == question['correct_answer']:
                score += question['marks']
        
        percentage = (score / total_marks * 100) if total_marks > 0 else 0
        
        # Save result
        conn.execute('''INSERT INTO results (student_id, assessment_id, score, total_marks, percentage)
                       VALUES (?, ?, ?, ?, ?)''',
                    (session['user_id'], assessment_id, score, total_marks, percentage))
        conn.commit()
        conn.close()
        
        flash(f'Assessment submitted! You scored {score}/{total_marks} ({percentage:.2f}%)', 'success')
        return redirect(url_for('student_dashboard'))
    
    # Check if already taken
    existing_result = conn.execute('SELECT * FROM results WHERE student_id = ? AND assessment_id = ?',
                                  (session['user_id'], assessment_id)).fetchone()
    
    if existing_result:
        flash('You have already taken this assessment.', 'info')
        conn.close()
        return redirect(url_for('student_dashboard'))
    
    assessment = conn.execute('''
        SELECT a.*, c.title as course_title
        FROM assessments a
        JOIN courses c ON a.course_id = c.id
        WHERE a.id = ?
    ''', (assessment_id,)).fetchone()
    
    questions = conn.execute('SELECT * FROM questions WHERE assessment_id = ?',
                            (assessment_id,)).fetchall()
    
    conn.close()
    
    return render_template('take_assessment.html', assessment=assessment, questions=questions)

@app.route('/student/my_performance')
@login_required
@role_required('student')
def my_performance():
    conn = get_db()
    
    results = conn.execute('''
        SELECT r.*, a.title as assessment_title, c.title as course_title
        FROM results r
        JOIN assessments a ON r.assessment_id = a.id
        JOIN courses c ON a.course_id = c.id
        WHERE r.student_id = ?
        ORDER BY r.submitted_at DESC
    ''', (session['user_id'],)).fetchall()
    
    # Calculate overall statistics
    if results:
        avg_percentage = sum(r['percentage'] for r in results) / len(results)
        total_assessments = len(results)
    else:
        avg_percentage = 0
        total_assessments = 0
    
    conn.close()
    
    return render_template('my_performance.html',
                         results=results,
                         avg_percentage=avg_percentage,
                         total_assessments=total_assessments)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)