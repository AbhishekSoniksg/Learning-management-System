# 📘 Online Learning Management System (LMS)

**Team Number:** Team 1  
**Project Type:** Academic Major Project

## 📋 Project Description

An Online Learning Management System designed to provide a centralized, scalable, and user-friendly platform for digital education, enabling administrators, instructors, and students to interact efficiently.

## 🛠️ Technologies Used

- **Frontend:** HTML, CSS, JavaScript, Bootstrap 5
- **Backend:** Python (Flask)
- **Database:** SQLite
- **Tools:** VS Code, Web Browser

## 🎯 Objectives

The primary objectives of the Online Learning Management System are:

1. To provide a centralized learning platform
2. To enable anytime, anywhere access to learning resources
3. To support role-based access (Admin, Instructor, Student)
4. To monitor and evaluate student performance effectively
5. To ensure a secure, scalable, and efficient system

## 🏗️ System Architecture

```
User (Browser)
     |
Frontend (HTML, CSS, JavaScript, Bootstrap)
     |
Backend (Python/Flask Application Logic)
     |
Database (SQLite)
```

### Data Flow
User requests → Frontend → Backend → Database → Backend → Frontend → User

## 📦 Module Description

### 🔹 Admin Module
- User registration and role assignment
- Course approval and management
- Monitoring system usage
- Generating analytics and reports
- System configuration and maintenance

### 🔹 Instructor Module
- Course creation and updates
- Uploading videos, documents, and resources
- Creating quizzes and assignments
- Monitoring student progress and performance
- Providing feedback and grades

### 🔹 Student Module
- Registration and secure login
- Course browsing and enrollment
- Access to learning materials
- Participation in quizzes and assignments
- Viewing performance reports and feedback

## 🔄 Workflow Process

```
Login → Dashboard → Course Selection → Learning Content
→ Assessment → Result → Database Update
```

## 💻 System Requirements

### Hardware Requirements
- Laptop / Desktop Computer
- Minimum 8 GB RAM
- Stable Internet Connection

### Software Requirements
- Python 3.8 or higher
- Modern Web Browser (Chrome, Firefox, Edge, Safari)
- VS Code or any text editor

## 📥 Installation & Setup

### Step 1: Install Python
Make sure Python 3.8+ is installed on your system. Check by running:
```bash
python --version
```

### Step 2: Install Dependencies
Navigate to the project directory and install required packages:
```bash
pip install -r requirements.txt
```

### Step 3: Run the Application
Start the Flask development server:
```bash
python app.py
```

### Step 4: Access the Application
Open your web browser and navigate to:
```
http://localhost:5000
```

## 🔐 Default Login Credentials

### Admin Account
- **Username:** admin
- **Password:** admin123

### Creating New Accounts
Users can register as:
- **Students** - for taking courses and assessments
- **Instructors** - for creating and managing courses

## 📁 Project Structure

```
lms_project/
│
├── app.py                  # Main Flask application
├── requirements.txt        # Python dependencies
├── README.md              # Project documentation
│
├── data/
│   └── lms.db             # SQLite database (auto-created)
│
├── static/
│   ├── css/
│   │   └── style.css      # Custom CSS styles
│   ├── js/
│   │   └── script.js      # JavaScript functions
│   └── images/            # Image assets
│
└── templates/
    ├── base.html          # Base template
    ├── login.html         # Login page
    ├── register.html      # Registration page
    │
    ├── admin_dashboard.html
    ├── admin_users.html
    ├── admin_analytics.html
    │
    ├── instructor_dashboard.html
    ├── create_course.html
    ├── instructor_course_details.html
    ├── create_assessment.html
    ├── add_questions.html
    ├── student_performance.html
    │
    ├── student_dashboard.html
    ├── student_course_view.html
    ├── take_assessment.html
    └── my_performance.html
```

## ✨ Features

### For Administrators
- ✅ User management and role assignment
- ✅ Course approval workflow
- ✅ System analytics and reporting
- ✅ Monitor platform usage

### For Instructors
- ✅ Create and manage courses
- ✅ Upload learning materials (videos, documents, resources)
- ✅ Create assessments with multiple-choice questions
- ✅ Track student performance
- ✅ View enrolled students

### For Students
- ✅ Browse and enroll in approved courses
- ✅ Access course materials
- ✅ Take assessments/quizzes
- ✅ View results and performance analytics
- ✅ Track learning progress

## 🔒 Security Features

- Password hashing using SHA-256
- Session-based authentication
- Role-based access control (RBAC)
- SQL injection prevention
- CSRF protection

## 📊 Database Schema

The system uses SQLite with the following main tables:

- **users** - Store user information and credentials
- **courses** - Course details and metadata
- **course_materials** - Learning content
- **enrollments** - Student-course relationships
- **assessments** - Quiz/exam information
- **questions** - Assessment questions
- **results** - Student performance data
- **assignments** - Assignment details
- **assignment_submissions** - Student submissions

## 🎓 Usage Guide

### As an Admin:
1. Log in with admin credentials
2. View pending course approvals
3. Approve or reject courses
4. Manage users
5. View analytics

### As an Instructor:
1. Register and log in
2. Create a new course
3. Wait for admin approval
4. Add learning materials
5. Create assessments with questions
6. Monitor student performance

### As a Student:
1. Register and log in
2. Browse available courses
3. Enroll in courses
4. Access learning materials
5. Take assessments
6. View your performance

## ✅ Advantages

- ✓ Flexible learning environment
- ✓ Cost-effective solution
- ✓ Scalable for large user base
- ✓ Real-time analytics and reports
- ✓ Improved student engagement
- ✓ Role-based access control
- ✓ Easy to deploy and maintain

## ⚠️ Limitations

- Requires internet connectivity
- Initial setup effort required
- Data security considerations for production
- SQLite has limitations for very large deployments

## 🌐 Applications

- Schools and colleges
- Corporate training platforms
- Online certification programs
- Coaching institutes
- Professional development courses

## 🔄 Project Life Cycle

The project follows the **Agile Methodology**:

1. **Requirement Gathering** - Understanding user needs
2. **System Design** - Architecture and database design
3. **Development** - Sprint-based implementation
4. **Testing** - Quality assurance
5. **Deployment** - Production release
6. **Maintenance** - Continuous improvement

## 🚀 Future Enhancements

- Video conferencing integration
- Discussion forums
- Certificate generation
- Mobile app development
- Advanced analytics dashboard
- Payment integration for paid courses
- Email notifications
- File upload for assignments
- Live chat support

## 📝 Development Notes

- Built with Flask for simplicity and flexibility
- Bootstrap 5 for responsive design
- SQLite for lightweight database management
- Modular code structure for easy maintenance
- Comprehensive error handling

## 🤝 Contributing

This is an academic project for Team 1. For any questions or contributions, please contact the project team.

## 📄 License

This project is developed for academic purposes.

## 👥 Team Information

**Team Number:** Team 1  
**Project Type:** Academic Major Project

---

**Note:** For production deployment, consider:
- Using PostgreSQL or MySQL instead of SQLite
- Implementing HTTPS
- Adding email verification
- Enhancing security measures
- Implementing proper logging
- Adding backup mechanisms
