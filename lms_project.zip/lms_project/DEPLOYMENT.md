# 🚀 Deployment Guide - Online LMS

## Table of Contents
1. [Local Development Setup](#local-development-setup)
2. [Testing the Application](#testing-the-application)
3. [Production Deployment](#production-deployment)
4. [Troubleshooting](#troubleshooting)

---

## Local Development Setup

### Step 1: System Requirements Check

**Minimum Requirements:**
- Python 3.8 or higher
- 8 GB RAM
- 500 MB free disk space
- Modern web browser

**Check Python version:**
```bash
python3 --version
# Should show: Python 3.8.x or higher
```

### Step 2: Project Setup

1. **Extract/Navigate to project:**
   ```bash
   cd lms_project
   ```

2. **Install dependencies:**
   ```bash
   pip3 install -r requirements.txt
   ```
   
   If you don't have pip:
   ```bash
   # On Ubuntu/Debian
   sudo apt-get install python3-pip
   
   # On macOS
   brew install python3
   
   # On Windows
   # Download from python.org
   ```

3. **Verify installation:**
   ```bash
   python3 -c "import flask; print('Flask installed successfully')"
   ```

### Step 3: Run the Application

**Option A: Using the run script (Linux/Mac)**
```bash
chmod +x run.sh
./run.sh
```

**Option B: Direct Python execution**
```bash
python3 app.py
```

**Option C: Using Flask command**
```bash
export FLASK_APP=app.py
export FLASK_ENV=development
flask run
```

### Step 4: Access the Application

1. Open your web browser
2. Navigate to: `http://localhost:5000`
3. You should see the login page

---

## Testing the Application

### Initial Test: Admin Login

1. Go to `http://localhost:5000`
2. Login with:
   - Username: `admin`
   - Password: `admin123`
3. You should see the admin dashboard

### Full System Test

#### 1. Create Test Instructor
```
Logout → Register
Full Name: Test Instructor
Username: instructor_test
Email: instructor@test.com
Password: test123
Role: Instructor
```

#### 2. Create Test Student
```
Logout → Register
Full Name: Test Student
Username: student_test
Email: student@test.com
Password: test123
Role: Student
```

#### 3. Create and Approve Course
```
Login as: instructor_test
Create Course:
  Title: Introduction to Python
  Description: Learn Python basics
  
Login as: admin
Dashboard → Approve the course

Login as: instructor_test
View course → Add materials → Create assessment
```

#### 4. Test Student Enrollment
```
Login as: student_test
Browse courses → Enroll → View materials → Take assessment
```

### Verification Checklist

- [ ] Admin can see all users
- [ ] Instructor can create courses
- [ ] Admin can approve courses
- [ ] Instructor can add materials
- [ ] Instructor can create assessments
- [ ] Students can enroll in courses
- [ ] Students can view materials
- [ ] Students can take assessments
- [ ] Results are calculated correctly
- [ ] Performance analytics work

---

## Production Deployment

### Important: Production Changes Required

Before deploying to production, make these changes:

#### 1. Change Secret Key

Edit `app.py`:
```python
# Change from:
app.secret_key = 'your_secret_key_here_change_in_production'

# To:
import secrets
app.secret_key = secrets.token_hex(32)
# Or set via environment variable
```

#### 2. Disable Debug Mode

Edit `app.py`:
```python
# Change from:
app.run(debug=True, host='0.0.0.0', port=5000)

# To:
app.run(debug=False, host='0.0.0.0', port=5000)
```

#### 3. Use Production Database

For production, consider using PostgreSQL or MySQL instead of SQLite:

```python
# Install additional packages
pip install psycopg2-binary  # For PostgreSQL
# or
pip install mysql-connector-python  # For MySQL
```

#### 4. Set Up HTTPS

Use a reverse proxy like Nginx:

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

#### 5. Use Production WSGI Server

Install Gunicorn:
```bash
pip install gunicorn
```

Run with Gunicorn:
```bash
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Cloud Deployment Options

#### Option A: Heroku
```bash
# Install Heroku CLI
heroku create lms-app
echo "web: gunicorn app:app" > Procfile
git push heroku main
```

#### Option B: AWS EC2
```bash
# 1. Launch EC2 instance
# 2. Install Python and dependencies
sudo apt update
sudo apt install python3-pip
pip3 install -r requirements.txt

# 3. Install and configure Nginx
sudo apt install nginx

# 4. Set up systemd service
sudo nano /etc/systemd/system/lms.service
```

#### Option C: DigitalOcean
```bash
# Similar to AWS EC2
# Use their droplets and follow Ubuntu setup
```

#### Option D: Docker Deployment

Create `Dockerfile`:
```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 5000

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]
```

Build and run:
```bash
docker build -t lms-app .
docker run -p 5000:5000 lms-app
```

---

## Troubleshooting

### Common Issues and Solutions

#### Issue 1: Port 5000 already in use
```bash
# Find process using port 5000
lsof -i :5000

# Kill the process
kill -9 <PID>

# Or change port in app.py
app.run(debug=True, host='0.0.0.0', port=8080)
```

#### Issue 2: Database errors
```bash
# Reset database
rm data/lms.db
python3 app.py
# This will recreate the database
```

#### Issue 3: Module not found errors
```bash
# Reinstall dependencies
pip3 install --upgrade -r requirements.txt
```

#### Issue 4: Cannot access from other devices
```bash
# Make sure you're binding to 0.0.0.0
# In app.py:
app.run(debug=True, host='0.0.0.0', port=5000)

# Check firewall
sudo ufw allow 5000
```

#### Issue 5: Permission denied (Linux)
```bash
# Make run.sh executable
chmod +x run.sh

# Or run with python directly
python3 app.py
```

#### Issue 6: Flask not found
```bash
# Install Flask
pip3 install flask

# Or install all requirements
pip3 install -r requirements.txt
```

### Debugging Tips

1. **Check Python version:**
   ```bash
   python3 --version
   ```

2. **Check Flask installation:**
   ```bash
   python3 -c "import flask; print(flask.__version__)"
   ```

3. **Check database:**
   ```bash
   ls -la data/
   # Should show lms.db file
   ```

4. **View error logs:**
   - Check terminal output
   - Look for traceback messages
   - Note the line numbers

5. **Test database connection:**
   ```bash
   python3 -c "import sqlite3; conn = sqlite3.connect('data/lms.db'); print('Database OK')"
   ```

### Getting Help

If you're still stuck:

1. Check the README.md file
2. Review QUICKSTART.md
3. Verify all requirements are met
4. Check Python version compatibility
5. Ensure all dependencies are installed

### Performance Tips

For better performance:

1. **Use production database:**
   - PostgreSQL for large scale
   - MySQL for medium scale
   - SQLite is fine for < 100 users

2. **Enable caching:**
   ```python
   from flask_caching import Cache
   cache = Cache(app, config={'CACHE_TYPE': 'simple'})
   ```

3. **Use CDN for static files:**
   - Bootstrap CSS/JS
   - Images and assets

4. **Optimize queries:**
   - Add database indexes
   - Use query optimization

---

## Security Checklist for Production

- [ ] Change secret key
- [ ] Disable debug mode
- [ ] Use HTTPS
- [ ] Set up firewall
- [ ] Regular backups
- [ ] Update dependencies
- [ ] Monitor logs
- [ ] Set up authentication limits
- [ ] Enable CORS properly
- [ ] Sanitize user inputs

---

## Monitoring and Maintenance

### Log Files
```bash
# Create logs directory
mkdir logs

# Configure logging in app.py
import logging
logging.basicConfig(filename='logs/lms.log', level=logging.INFO)
```

### Database Backup
```bash
# Backup database
cp data/lms.db data/lms_backup_$(date +%Y%m%d).db

# Automate backups (cron)
0 2 * * * cp /path/to/data/lms.db /path/to/backups/lms_$(date +\%Y\%m\%d).db
```

### Updates
```bash
# Update dependencies
pip3 install --upgrade -r requirements.txt

# Restart application
# (method depends on deployment)
```

---

## Next Steps

After successful deployment:

1. Create backup admin account
2. Set up monitoring
3. Configure email notifications (future feature)
4. Set up regular backups
5. Monitor system performance
6. Plan for scaling

---

**Deployment Status Checklist:**

Local Development:
- [ ] Dependencies installed
- [ ] Application runs
- [ ] Database created
- [ ] Login works
- [ ] All features tested

Production Ready:
- [ ] Secret key changed
- [ ] Debug mode disabled
- [ ] HTTPS configured
- [ ] Production server setup
- [ ] Backups configured
- [ ] Monitoring in place

---

**Note:** This LMS is ready for educational/academic use. For production deployment with real users, additional security measures and performance optimizations are recommended.
