from app import create_app
from extensions import db
from models import Course

app = create_app()

with app.app_context():
    # Update Python Course
    c1 = Course.query.filter_by(title='Complete Python Bootcamp').first()
    if c1:
        c1.thumbnail = 'images/course_python.png'
    
    # Update Web Dev Course
    c2 = Course.query.filter_by(title='Modern Web Development').first()
    if c2:
        c2.thumbnail = 'images/course_webdev.png'

    # Update ML Course
    c3 = Course.query.filter_by(title='Machine Learning A-Z').first()
    if c3:
        c3.thumbnail = 'images/course_ml.png'

    db.session.commit()
    print("Database Updated Successfully!")
