from app import create_app
from extensions import db
from models import Course

app = create_app()

with app.app_context():
    courses = Course.query.all()
    print("-" * 30)
    for c in courses:
        print(f"Course: {c.title}")
        print(f"Thumbnail DB Value: '{c.thumbnail}'")
    print("-" * 30)
