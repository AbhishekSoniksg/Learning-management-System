from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from extensions import db
from models import Course, Enrollment, Quiz, Result, Question
from datetime import datetime

student_bp = Blueprint('student', __name__)

@student_bp.route('/dashboard')
@login_required
def dashboard():
    enrollments = Enrollment.query.filter_by(user_id=current_user.id).all()
    
    # Simple Gamification: Badges based on completed courses
    completed_count = sum(1 for e in enrollments if e.completed)
    badges = []
    if completed_count >= 1:
        badges.append({'name': 'First Step', 'icon': 'bi-award', 'color': 'success'})
    if completed_count >= 3:
        badges.append({'name': 'Dedicated Learner', 'icon': 'bi-star-fill', 'color': 'warning'})
    if completed_count >= 5:
        badges.append({'name': 'Master Scholar', 'icon': 'bi-trophy-fill', 'color': 'info'})

    return render_template('dashboard/student_dashboard.html', user=current_user, enrollments=enrollments, badges=badges)

@student_bp.route('/courses')
@login_required
def browse_courses():
    courses = Course.query.filter_by(status='Approved').all() # STRICT MODE: Only approved
    user_enrollments = Enrollment.query.filter_by(user_id=current_user.id).all()
    enrolled_course_ids = [e.course_id for e in user_enrollments]
    return render_template('courses/course_list.html', courses=courses, enrolled_course_ids=enrolled_course_ids)

# ... (enroll route remains same, skipped for brevity in replacement if not modifying) ...
@student_bp.route('/enroll/<int:course_id>', methods=['POST'])
@login_required
def enroll(course_id):
    existing = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    if existing:
        flash('Already enrolled.', 'info')
        return redirect(url_for('student.browse_courses'))
    
    enrollment = Enrollment(user_id=current_user.id, course_id=course_id)
    db.session.add(enrollment)
    db.session.commit()
    flash('Successfully enrolled! Check your dashboard.', 'success')
    return redirect(url_for('student.dashboard'))

@student_bp.route('/learn/<int:course_id>')
@login_required
def learning_page(course_id):
    course = Course.query.get_or_404(course_id)
    enrollment = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    if not enrollment:
         flash('Please enroll first.', 'danger')
         return redirect(url_for('student.browse_courses'))
    
    quizzes = Quiz.query.filter_by(course_id=course.id).all()
    # Check if quiz taken
    taken_quizzes = [r.quiz_id for r in current_user.results]
    
    return render_template('courses/learn.html', course=course, enrollment=enrollment, quizzes=quizzes, taken_quizzes=taken_quizzes)

@student_bp.route('/quiz/<int:quiz_id>', methods=['GET', 'POST'])
@login_required
def take_quiz(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    if request.method == 'POST':
        score = 0
        total_questions = len(quiz.questions)
        for q in quiz.questions:
            selected_option = request.form.get(f'q_{q.id}')
            if selected_option == q.correct_option:
                score += 1
        
        # Calculate percentage or store raw score
        # For simplicity, let's store raw score
        result = Result(user_id=current_user.id, quiz_id=quiz.id, score=score)
        db.session.add(result)
        db.session.commit()
        
        # Auto-complete course if key quiz passed? (Optional gamification)
        
        flash(f'Quiz Submitted! You scored {score}/{total_questions}', 'info')
        return redirect(url_for('student.learning_page', course_id=quiz.course_id))

    return render_template('courses/take_quiz.html', quiz=quiz)

@student_bp.route('/complete/<int:course_id>', methods=['POST'])
@login_required
def mark_complete(course_id):
    enrollment = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    if enrollment:
        if enrollment.progress < 100:
            enrollment.progress = min(100, enrollment.progress + 25)
        
        if enrollment.progress == 100:
            enrollment.completed = True
            
        db.session.commit()
    return redirect(url_for('student.dashboard'))

@student_bp.route('/certificate/<int:course_id>')
@login_required
def certificate(course_id):
    enrollment = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    if not enrollment or not enrollment.completed:
        flash('Complete the course to get the certificate!', 'warning')
        return redirect(url_for('student.dashboard'))
        
    return render_template('certificates/certificate.html', user=current_user, course=enrollment.course, date=datetime.now().strftime('%Y-%m-%d'))
