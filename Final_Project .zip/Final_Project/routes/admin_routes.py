from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from extensions import db
from models import User, Course

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    users = User.query.all()
    courses = Course.query.all()
    pending_courses = [c for c in courses if c.status == 'Pending']
    return render_template('dashboard/admin_dashboard.html', user=current_user, users=users, courses=courses, pending_courses=pending_courses)

@admin_bp.route('/approve-course/<int:course_id>')
@login_required
def approve_course(course_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    course = Course.query.get_or_404(course_id)
    course.status = 'Approved'
    db.session.commit()
    flash(f'Course "{course.title}" approved!', 'success')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/delete-user/<int:user_id>')
@login_required
def delete_user(user_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.home'))
    user = User.query.get_or_404(user_id)
    if user.role == 'admin':
         flash('Cannot delete an admin.', 'danger')
    else:
        db.session.delete(user)
        db.session.commit()
        flash('User deleted.', 'info')
    return redirect(url_for('admin.dashboard'))
