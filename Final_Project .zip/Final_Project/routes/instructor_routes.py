from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from extensions import db
from models import Course, Content, Quiz, Question

instructor_bp = Blueprint('instructor', __name__)

@instructor_bp.route('/dashboard')
@login_required
def dashboard():
    courses = Course.query.filter_by(instructor_id=current_user.id).all()
    return render_template('dashboard/instructor_dashboard.html', user=current_user, courses=courses)

@instructor_bp.route('/create_course', methods=['GET', 'POST'])
@login_required
def create_course():
    if current_user.role != 'instructor':
        flash('Access Denied', 'danger')
        return redirect(url_for('main.home'))

    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        
        course = Course(title=title, description=description, instructor_id=current_user.id)
        db.session.add(course)
        db.session.commit()
        flash('Course created! Waiting for Admin approval.', 'success')
        return redirect(url_for('instructor.dashboard'))

    return render_template('courses/create_course.html')

@instructor_bp.route('/course/<int:course_id>/add-content', methods=['GET', 'POST'])
@login_required
def add_content(course_id):
    course = Course.query.get_or_404(course_id)
    if course.instructor_id != current_user.id:
        flash('Unauthorized', 'danger')
        return redirect(url_for('instructor.dashboard'))
        
    if request.method == 'POST':
        title = request.form.get('title')
        content_type = request.form.get('type')
        # Here we would handle file upload, for now simulating with a text path
        file_path = request.form.get('file_path', 'demo_link')
        
        content = Content(course_id=course.id, title=title, type=content_type, file_path=file_path)
        db.session.add(content)
        db.session.commit()
        flash('Content added successfully!', 'success')
        return redirect(url_for('instructor.dashboard'))
        
    return render_template('courses/add_content.html', course=course)

@instructor_bp.route('/course/<int:course_id>/create-quiz', methods=['GET', 'POST'])
@login_required
def create_quiz(course_id):
    course = Course.query.get_or_404(course_id)
    if course.instructor_id != current_user.id:
        flash('Unauthorized', 'danger')
        return redirect(url_for('instructor.dashboard'))

    if request.method == 'POST':
        title = request.form.get('title')
        quiz = Quiz(course_id=course.id, title=title)
        db.session.add(quiz)
        db.session.commit()
        
        # Add a demo question
        q_text = request.form.get('question')
        q = Question(quiz_id=quiz.id, question_text=q_text, 
                    option_a="A", option_b="B", option_c="C", option_d="D", 
                    correct_option="A")
        db.session.add(q)
        db.session.commit()
        
        flash('Quiz created!', 'success')
        return redirect(url_for('instructor.dashboard'))

    return render_template('courses/create_quiz.html', course=course)
