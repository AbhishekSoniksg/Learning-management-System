from flask import Flask, render_template, redirect, url_for
from flask import Flask, render_template, redirect, url_for
import os

from extensions import db, login_manager, bcrypt
import os

# Initialize extensions (Moved to extensions.py)

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = 'dev_secret_key_change_in_production' # fast dev key
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///lms.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Init extensions
    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'

    # Import and Register Blueprints
    from routes.auth_routes import auth_bp
    from routes.admin_routes import admin_bp
    from routes.instructor_routes import instructor_bp
    from routes.student_routes import student_bp
    from routes.main_routes import main_bp

    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(instructor_bp, url_prefix='/instructor')
    app.register_blueprint(student_bp, url_prefix='/student')
    app.register_blueprint(main_bp) # Root routes

    # Create Database Tables
    with app.app_context():
        import models # Import models to ensure they are registered
        db.create_all()

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
